import json
from botocore.exceptions import ClientError
import boto3
import time


def lambda_handler(event, context):
    # TODO implement
    time.sleep(600)
    print(event)
    account_id = event['detail']['userIdentity']['accountId']
    fun(account_id)
    return {
        'statusCode': 200,
        'body': json.dumps('Enabled the S3 block public access block config rule and added the auto remediation !')
    }


def fun(account_id):
    account_id = account_id
    sts_connection = boto3.client('sts')
    acct_b = sts_connection.assume_role(
        RoleArn="arn:aws:iam::" + account_id + ":role/AWSControlTowerExecution",
        RoleSessionName="cross_acct_lambda"
    )

    input_parameters = {'IgnorePublicAcls': 'True', 'BlockPublicPolicy': 'True', 'BlockPublicAcls': 'True',
                        'RestrictPublicBuckets': 'True'}

    parameters = json.dumps(input_parameters)

    account_credentials = {'AccessKeyId': acct_b['Credentials']['AccessKeyId'],
                           'SecretAccessKey': acct_b['Credentials']['SecretAccessKey'],
                           'SessionToken': acct_b['Credentials']['SessionToken'],
                           'AccountNumber': account_id}
    RegionList = ['us-east-1', 'us-east-2', 'us-west-2', 'eu-west-1', 'ap-southeast-2', 'ap-southeast-1',
                  'eu-central-1', 'eu-north-1', 'eu-west-2', 'ca-central-1']
    iam_session = boto3.Session(
        aws_access_key_id=account_credentials['AccessKeyId'],
        aws_secret_access_key=account_credentials['SecretAccessKey'],
        aws_session_token=account_credentials['SessionToken'])
        
    iam_client = iam_session.client('iam')
    iam_role_arn = ""
    
    assume_role_policy_document = json.dumps({
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {
                    "Service": [
                      "ssm.amazonaws.com",
                      "config.amazonaws.com"
                    ]
                },
                "Action": "sts:AssumeRole"
            }
        ]
    })
    print("-------- creating a role for Config and SSM ---------")

    try:
        create_iamrole_response = iam_client.create_role(
            RoleName="ssm-config-assume-role",
            AssumeRolePolicyDocument = assume_role_policy_document
        )
        attach_policy_response = iam_client.attach_role_policy(
            RoleName='ssm-config-assume-role',
            PolicyArn='arn:aws:iam::aws:policy/AdministratorAccess'
        )
        print(create_iamrole_response)
        print(attach_policy_response)
        iam_role_arn = create_iamrole_response['Role']['Arn']
    except ClientError as my_Error:
        print(my_Error)
    for region in RegionList:
        print('-------------'+region+'----------------')
        session = boto3.Session(
            aws_access_key_id=account_credentials['AccessKeyId'],
            aws_secret_access_key=account_credentials['SecretAccessKey'],
            aws_session_token=account_credentials['SessionToken'],
            region_name=region)
        client = session.client('config')
        '''
        print("-------- Enable Config recorder ---------")
        try:
            response = client.put_configuration_recorder(
                ConfigurationRecorder={
                    'name': 'ControlTower-ConfigurationRecorder',
                    'roleARN': iam_role_arn,
                    'recordingGroup': {
                        'allSupported': True,
                        'includeGlobalResourceTypes': True
                    }
                }
            )
            snsTopicARN="arn:aws:sns:"+region+":850761021763:aws-controltower-AllConfigNotifications"
            response = client.put_delivery_channel(
                DeliveryChannel={
                    'name': 'ControlTower-DeliveryChannel',
                    's3BucketName': 'aws-controltower-logs-249261437155-us-east-1',
                    'snsTopicARN': snsTopicARN,
                    'configSnapshotDeliveryProperties': {
                        'deliveryFrequency': 'TwentyFour_Hours'
                    }
                }
            )
            print(response)
        except ClientError as my_Error:
            print(my_Error)
        '''
        print("-------- Enabling S3 Account level public access blocks config rule --------")
        try:
            response = client.put_config_rule(ConfigRule={
                'ConfigRuleName': 's3-account-level-public-access-blocks',
                'Description': 'Checks whether the required public access block settings are configured from account level. The rule is NON_COMPLIANT when the public access block settings are not configured from account level.',
                'Source': {
                    'Owner': 'AWS',
                    'SourceIdentifier': 'S3_ACCOUNT_LEVEL_PUBLIC_ACCESS_BLOCKS'
                },
                'ConfigRuleState': 'ACTIVE',
                'InputParameters': parameters
            }
            )
            print(response)
        except ClientError as my_Error:
            print(my_Error)

        print("-------- Enabling the Auto remediation for S3 Account level public access blocks config rule --------")
        try:
            response = client.put_remediation_configurations(
                RemediationConfigurations=[
                    {
                        'ConfigRuleName': 's3-account-level-public-access-blocks',
                        'TargetType': 'SSM_DOCUMENT',
                        'TargetId': 'AWSConfigRemediation-ConfigureS3PublicAccessBlock',
                        'TargetVersion': '2',
                        'Automatic': True,
                        'Parameters': {
                            'AutomationAssumeRole': {
                                'StaticValue': {
                                    'Values': [
                                        iam_role_arn
                                    ]
                                }
                            },
                            'AccountId': {
                                'StaticValue': {
                                    'Values': [
                                        account_id
                                    ]
                                }
                            },
                            'IgnorePublicAcls': {
                                'StaticValue': {
                                    'Values': [
                                        "true"
                                    ]
                                }
                            },
                            'BlockPublicPolicy': {
                                'StaticValue': {
                                    'Values': [
                                        "true"
                                    ]
                                }
                            },
                            'BlockPublicAcls': {
                                'StaticValue': {
                                    'Values': [
                                        "true"
                                    ]
                                }
                            },
                            'RestrictPublicBuckets': {
                                'StaticValue': {
                                    'Values': [
                                        "true"
                                    ]
                                }
                            }
                        },
                        'MaximumAutomaticAttempts': 5,
                        'RetryAttemptSeconds': 60,
                    }
                ]
            )
            print(response)
        except ClientError as my_Error:
            print(my_Error)
